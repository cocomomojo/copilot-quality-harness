/* copilot-generated */

import { expect, test } from '@playwright/test';

test.describe('User Profile - Account Created At Display (E2E)', () => {
  // Use environment variables with fallback to default values
  // Can be configured via: BACKEND_API_URL=http://custom-host:3000 npm run test:e2e
  const apiUrl = process.env.BACKEND_API_URL || 'http://127.0.0.1:3000';

  // E2E-001: Normal case - logged-in user with valid createdAt
  test('E2E-001: Display profile with valid createdAt', async ({ page, request }) => {
    // Setup: Seed database with user
    const seedResponse = await request.post(`${apiUrl}/api/test/seed-user`, {
      data: {
        id: 'user-123',
        email: 'testuser@example.com',
        name: 'Test User',
        created_at: '2026-10-18T10:00:00Z'
      }
    }).catch((err) => {
      console.error('Seed user failed:', err);
    });

    // Navigate to profile page (uses baseURL from playwright.config.js)
    await page.goto('/profile');
    
    // Wait for loading state to disappear and content to load
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(500); // Additional wait for React state update
    
    // Wait for heading to be visible
    await page.waitForSelector('h1:has-text("プロフィール")', { timeout: 5000 });

    // Verify page title and headings
    await expect(page.getByRole('heading', { name: /プロフィール/i })).toBeVisible();
    await expect(page.getByText(/アカウント作成日/i)).toBeVisible();

    // Step 2: Assert date is displayed
    await expect(page.getByText('2026年10月18日')).toBeVisible({ timeout: 3000 });

    // Step 3: Assert element is present and visible
    const createdAtElement = page.locator('[data-testid="account-created-at"]');
    await expect(createdAtElement).toBeVisible();

    // Step 4: Assert formatted date in the value element
    const createdAtValue = page.locator('[data-testid="account-created-at-value"]');
    await expect(createdAtValue).toContainText('2026年10月18日');
  });

  // E2E-002: Error case - null createdAt with fallback display
  test('E2E-002: Display fallback when createdAt is null', async ({ page, request }) => {
    // Setup: Seed database with user without createdAt
    await request.post(`${apiUrl}/api/test/seed-user`, {
      data: {
        id: 'user-456',
        email: 'legacyuser@example.com',
        name: 'Legacy User',
        created_at: null
      }
    }).catch((err) => {
      console.error('Seed user failed:', err);
    });

    // Navigate to profile page (uses baseURL from playwright.config.js)
    await page.goto('/profile');
    
    // Wait for loading state to disappear
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(500);
    await page.waitForSelector('h1:has-text("プロフィール")', { timeout: 5000 });

    // Verify page displays
    await expect(page.getByRole('heading', { name: /プロフィール/i })).toBeVisible();
    await expect(page.getByText(/アカウント作成日/i)).toBeVisible();

    // Step 2: Assert element is present
    const createdAtElement = page.locator('[data-testid="account-created-at"]');
    await expect(createdAtElement).toBeVisible();

    // Step 3: Assert fallback text (dash or 未設定)
    const createdAtValue = page.locator('[data-testid="account-created-at-value"]');
    const text = await createdAtValue.textContent();
    expect(text?.trim()).toMatch(/^(-|未設定)$/);
  });

  // E2E-003: Error case - API returns 404 (no user exists)
  test('E2E-003: Handle 404 API error when user not found', async ({ page, request }) => {
    // Setup: Reset users to ensure no user exists
    try {
      await request.post(`${apiUrl}/api/test/reset-users`, {});
      await page.waitForTimeout(200);
    } catch (error) {
      console.log('Reset users endpoint not available');
    }
    
    // Navigate to profile page without user data
    await page.goto('/profile');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(500);

    // Verify error message is displayed
    const errorText = page.getByText(/ユーザープロフィール取得に失敗しました|ユーザー情報を取得できません/i);
    await expect(errorText).toBeVisible({ timeout: 5000 });
  });

  // E2E-004: Normal case - fetch and display from API
  test('E2E-004: Fetch createdAt from API and display formatted', async ({ page, request }) => {
    // Step 1: Call API endpoint directly
    const response = await request.get(`${apiUrl}/api/user/me`).catch(() => null);

    // Only verify format if user exists
    if (response && response.ok()) {
      const data = await response.json();
      
      // Verify response has createdAt in ISO8601 format
      if (data.created_at) {
        expect(data.created_at).toMatch(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/);
      }
    }

    // Step 2 & 3: Navigate to profile and verify date format (uses baseURL from playwright.config.js)
    await page.goto('/profile');
    await page.waitForLoadState('networkidle');
    
    // Verify profile page
    const heading = page.getByRole('heading', { name: /プロフィール/i });
    if (await heading.isVisible().catch(() => false)) {
      // If profile loads, verify date format pattern
      const dateElement = page.locator('[data-testid="account-created-at-value"]');
      const dateText = await dateElement.textContent().catch(() => '');
      
      // Verify it matches Japanese date format or fallback
      expect(dateText?.trim()).toMatch(/(\d{4}年\d{1,2}月\d{1,2}日|-|未設定)/);
    }
  });

  // E2E-005: Error case - invalid createdAt format in API response
  test('E2E-005: Handle invalid createdAt format with fallback', async ({ page, request }) => {
    // Setup: Mock or seed user with invalid date
    await request.post(`${apiUrl}/api/test/seed-user`, {
      data: {
        id: 'user-789',
        email: 'user@example.com',
        name: 'Test User',
        created_at: 'not-a-valid-date'
      }
    }).catch(() => {
      // Endpoint might not exist, continue with test
    });

    // Navigate to profile (uses baseURL from playwright.config.js)
    await page.goto('/profile');
    await page.waitForLoadState('networkidle');

    // Verify page displays
    const heading = page.getByRole('heading', { name: /プロフィール/i });
    if (await heading.isVisible().catch(() => false)) {
      // Verify fallback display
      const createdAtValue = page.locator('[data-testid="account-created-at-value"]');
      const text = await createdAtValue.textContent().catch(() => '');
      expect(text?.trim()).toMatch(/^(-|未設定)$/);
    }
  });

  // Additional E2E tests for robustness
  test('E2E-006: Verify element structure and accessibility', async ({ page, request }) => {
    // Setup user
    await request.post(`${apiUrl}/api/test/seed-user`, {
      data: {
        id: 'user-123',
        email: 'testuser@example.com',
        name: 'Test User',
        created_at: '2026-10-18T10:00:00Z'
      }
    }).catch(() => {});

    // Navigate (uses baseURL from playwright.config.js)
    await page.goto('/profile');

    // Verify main structure
    const main = page.locator('main');
    await expect(main).toBeVisible().catch(() => {});

    // Verify heading hierarchy
    const h1 = page.getByRole('heading', { level: 1 });
    await expect(h1).toBeVisible().catch(() => {});
  });

  test('E2E-007: Verify multiple renders and state consistency', async ({ page, request }) => {
    // Setup
    await request.post(`${apiUrl}/api/test/seed-user`, {
      data: {
        id: 'user-123',
        email: 'testuser@example.com',
        name: 'Test User',
        created_at: '2026-10-18T10:00:00Z'
      }
    }).catch(() => {});

    // Navigate and verify (uses baseURL from playwright.config.js)
    await page.goto('/profile');

    const createdAtValue = page.locator('[data-testid="account-created-at-value"]');
    
    // First check
    const firstText = await createdAtValue.textContent().catch(() => null);

    // Navigate away and back
    await page.goto(`${apiUrl}/`);
    await page.goto(`${apiUrl}/profile`);

    // Second check - should be consistent
    const secondText = await createdAtValue.textContent().catch(() => null);

    if (firstText && secondText) {
      expect(firstText).toBe(secondText);
    }
  });

  // E2E-101: Avatar image display (Issue #65)
  test('E2E-101: Display user avatar image when available', async ({ page, request }) => {
    // Setup: Seed user with avatar URL
    await request.post(`${apiUrl}/api/test/seed-user`, {
      data: {
        id: 'user-avatar-1',
        email: 'avatar@example.com',
        name: 'Avatar User',
        avatar_url: 'https://i.pravatar.cc/150?img=1',
        created_at: '2026-10-18T10:00:00Z'
      }
    });

    // Navigate to profile page
    await page.goto('/profile');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(500);

    // Verify avatar image is visible
    const avatar = page.locator('[data-testid="user-avatar"]');
    await expect(avatar).toBeVisible();
    
    // Verify avatar src contains expected URL
    await expect(avatar).toHaveAttribute('src', /avatar/);
  });

  // E2E-102: Default avatar display when not provided
  test('E2E-102: Display default avatar when avatar_url is not provided', async ({ page, request }) => {
    // Setup: Seed user without avatar
    await request.post(`${apiUrl}/api/test/seed-user`, {
      data: {
        id: 'user-avatar-2',
        email: 'noavatar@example.com',
        name: 'No Avatar User',
        avatar_url: null,
        created_at: '2026-10-18T10:00:00Z'
      }
    });

    // Navigate to profile page
    await page.goto('/profile');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(500);

    // Verify avatar image is visible
    const avatar = page.locator('[data-testid="user-avatar"]');
    await expect(avatar).toBeVisible();
    
    // Verify default avatar (data URI with SVG)
    await expect(avatar).toHaveAttribute('src', /data:image\/svg/);
  });

  // E2E-103: Avatar styling (responsive design)
  test('E2E-103: Avatar displays with correct styling and dimensions', async ({ page, request }) => {
    // Setup: Seed user with avatar
    await request.post(`${apiUrl}/api/test/seed-user`, {
      data: {
        id: 'user-avatar-3',
        email: 'styled@example.com',
        name: 'Styled Avatar User',
        avatar_url: 'https://i.pravatar.cc/150?img=2',
        created_at: '2026-10-18T10:00:00Z'
      }
    });

    // Navigate to profile page
    await page.goto('/profile');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(500);

    // Get avatar element
    const avatar = page.locator('[data-testid="user-avatar"]');
    
    // Verify avatar is visible
    await expect(avatar).toBeVisible();
    
    // Check styling (border and border-radius)
    const boundingBox = await avatar.boundingBox();
    
    // Avatar should be square (width ~= height)
    if (boundingBox) {
      const aspectRatio = boundingBox.width / boundingBox.height;
      expect(aspectRatio).toBeCloseTo(1, 0.1); // Allow 10% deviation
    }
  });
});
